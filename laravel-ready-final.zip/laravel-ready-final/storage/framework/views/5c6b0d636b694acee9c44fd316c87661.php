<!DOCTYPE html>
<html>
<head><title>Productos</title></head>
<body>
  <h1>Gestión de Productos</h1>

  <?php if(session('success')): ?>
    <p style="color:green"><?php echo e(session('success')); ?></p>
  <?php endif; ?>

  <form method="POST" action="<?php echo e(route('products.store')); ?>">
    <?php echo csrf_field(); ?>
    <input name="name" placeholder="Nombre" required>
    <input name="price" placeholder="Precio" required type="number" step="0.01">
    <textarea name="description" placeholder="Descripción"></textarea>
    <button type="submit">Crear</button>
  </form>

  <ul>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li>
        <form method="POST" action="<?php echo e(route('products.update', $product)); ?>" style="display:inline-block; margin-bottom: 10px;">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <input name="name" value="<?php echo e($product->name); ?>" required>
          <input name="price" value="<?php echo e($product->price); ?>" required type="number" step="0.01">
          <input name="description" value="<?php echo e($product->description); ?>">
          <button type="submit">Actualizar</button>
        </form>

        <form method="POST" action="<?php echo e(route('products.destroy', $product)); ?>" style="display:inline">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <button type="submit">Eliminar</button>
        </form>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</body>
</html>
<?php /**PATH /var/www/resources/views/products/index.blade.php ENDPATH**/ ?>